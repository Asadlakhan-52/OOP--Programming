class Employee2{
	String empName;
	String empID;
	double salary;

	Employee2(String empName, String empID , double salary){
  this.empName=empName;
  this.empID=empID;
  this.salary=salary;
	}

	public void increaseSalary(int amount){
   salary+=amount;
	}

public double calculateAnnualSalary(){
return salary*12;
}

 public void displayDetails(){
 	System.out.println("Employee Name :"+empName);
 	System.out.println("Employee ID :"+empID);
 	System.out.println("Employee Total Salary :"+salary);
 	 	
 }

 public static void main(String [] args){
Employee2 e1 = new Employee2(" Nabeel ","ARI-67" , 70000);

e1.increaseSalary(2000);
e1.displayDetails();
System.out.println("Annual Salary of Employee : "+e1.calculateAnnualSalary());
 }

}