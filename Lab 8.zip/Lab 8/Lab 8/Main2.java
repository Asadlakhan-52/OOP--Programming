class Main2{
	public static void main(String[] args) {
		
	
	Temperature temp= new Temperature();

	temp.setCelcius(25);
	System.out.print("Farheight :"+temp.getForenheight());

}
}