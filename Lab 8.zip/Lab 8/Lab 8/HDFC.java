class HDFC extends Bank{
	@Override
	public double getInterest(){
		return 6.8;
	
	}
}