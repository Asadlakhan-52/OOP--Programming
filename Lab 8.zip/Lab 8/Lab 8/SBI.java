class SBI extends Bank{
	@Override
	public double getInterest(){
		return 7.5;
	}
}