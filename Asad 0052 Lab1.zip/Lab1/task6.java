			// Task 06:
	public class task6{
	public static void main (String [] args){
	double dollar=3.3;
	double rupe=288;
	System.out.println("Numeber in Dollars : "+dollar);
	System.out.println("Value in Rupees is ="+rupe*dollar);
}
}
	