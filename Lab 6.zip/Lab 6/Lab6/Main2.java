class Main2{
    public static void main(String args []){

 GraduateStudent G= new GraduateStudent("Musbah",23,"ARI75","AI");
 
    G.displayInfo();
        
    }
}