class Main{
	public static void main(String args []){
		Shape shape;

		shape = new Circle();
		shape.draw();

System.out.println();

		shape = new Rectangle();
		shape.draw();
	}
}